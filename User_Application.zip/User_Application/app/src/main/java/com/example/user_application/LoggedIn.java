package com.example.user_application;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoggedIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in);

        TextView userdisp
                = (TextView)findViewById(R.id.userdisp);
        TextView passdisp
                = (TextView)findViewById(R.id.passdisp);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");
        userdisp.setText(username);
        passdisp.setText(password);
    }
}